define({
  "name": "SOGo",
  "version": "3.0.0",
  "description": "JSON Web API of SOGo",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-12-29T03:02:40.408Z",
    "url": "https://apidocjs.com",
    "version": "0.25.0"
  }
});
